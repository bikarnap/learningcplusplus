#include <iostream>
#include "Header.h"
using namespace std; 

float current(float voltage, float resistance) {
	return voltage / resistance;
}