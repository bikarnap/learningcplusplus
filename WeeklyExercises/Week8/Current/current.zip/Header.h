#pragma once
#ifndef HEADER_H
#define HEADER_H
float current(float, float);
#endif // !HEADER_H

