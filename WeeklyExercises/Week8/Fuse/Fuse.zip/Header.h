#pragma once
#ifndef HEADER_H
#define HEADER_H
void fuse(int);
#endif // !HEADER_H
