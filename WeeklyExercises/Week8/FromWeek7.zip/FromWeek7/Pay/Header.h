#pragma once
#ifndef HEADER_H
#define HEADER_H
float pay(float);
#endif // !HEADER_H

