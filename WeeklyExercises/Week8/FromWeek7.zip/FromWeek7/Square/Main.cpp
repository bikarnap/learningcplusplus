#include <iostream>
#include "Header.h"
using namespace std;

int main() {

	int square1 = square(5); 
	cout << "Square of 5 is " << square1;
}