#include <iostream>
#include "Header.h"
using namespace std;

int square(int number) {
	return number * number; 
}