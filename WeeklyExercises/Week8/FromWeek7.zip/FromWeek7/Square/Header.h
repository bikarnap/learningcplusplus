#pragma once
#ifndef HEADER_H
#define HEADER_H

int square(int);

#endif
