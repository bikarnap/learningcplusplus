#include <iostream>
#include "Header.h"
using namespace std;

int main() {
	float rectangular1 = rectangular(3.4, 3.4);
	cout << rectangular1;
}