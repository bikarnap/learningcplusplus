// Functions
// Function created float rectangular(float, float) to calculate the area of a rectangle when length
// and height of a rectangle is passed as arguments

#include <iostream>
#include "Header.h"
using namespace std; 

float rectangular(float length, float width) {
	return length * width; 
}